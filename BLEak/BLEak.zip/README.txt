Package Requirements
  1 = Python
  2 = Bleak
  3 = more-itertools

Launch Windows PowerShell
  1. Press "Windows Button" or navigate to "Windows Icon"
  2. Type "Windows PowerShell"
  3. Run Windows PowerShell by pressing Enter Key

  In Windows PowerShell

  |*****ADD PYTHON INSTALLATION PROCESS*****|

      py -m pip install bleak
      py -m pip install more-itertools
      py -m pip install pyserial

Navigate to script directory and run:
py example_BLEak.py

Compatible with Kenobi boards and Kashmir EB4+ boards
